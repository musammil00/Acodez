<?php return array('dependencies' => array(), 'version' => 'c181ec91430cb52fddaa');
